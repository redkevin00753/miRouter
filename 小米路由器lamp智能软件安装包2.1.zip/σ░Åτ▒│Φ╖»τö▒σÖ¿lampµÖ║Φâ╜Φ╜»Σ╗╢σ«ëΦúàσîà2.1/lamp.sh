#!/bin/sh

lamp="lamp"
WebSystem="data/WebSystem"
duanko="8088"
admin="admin"
setup_ok=0
if  [ ! -z "$1" ] ; then

if  [ ! -z "$2" ] ;  then
lamp=$2
fi

if [ ! -z "$3" ] ; then
WebSystem=$3
fi

if  [ ! -z "$4" ] ; then
duanko=$4
fi

if  [ ! -z "$5" ] ; then
admin=$5
fi

if [ $1 == "move" ] ; then
setup_ok=1
fi

fi

#  fix 
if [ ! -z  "$1" ] ; then
if [ $1 == "fix" ]; then

if grep -q 'open_1'  /etc/rc.local;then
echo "This router has been installing this plug-in, without repair!"
exit
else
mount -o remount rw /

if grep -q '#open_1' /etc/rc.local ; then
#sed -i -n '$!N;/\n#open_1/!P;D' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/d'  /etc/rc.local
fi

# add lamp to  rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\nmount -o bind \/userdisk\/'$lamp'\/data\/www\/document_root \/userdisk\/'$WebSystem'\n/' /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\nmount -o bind \/userdisk\/'$lamp'\/data\/www\/document_root \/userdisk\/'$WebSystem'\n/' /etc/rc.local

#sed -i '$!N;$!P;$!D;s/\(\n\)/\n#open_1 lamp\n/' /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\n\/userdisk\/'$lamp'\/lampmanager\/mount_things.sh\n/' /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\n\/userdisk\/'$lamp'\/lampmanager\/start_dropbear.sh\n/' /etc/rc.local

sed -i '$!N;$!P;$!D;s/\(\n\)/\n#open_1 lamp\n/' /etc/rc.local
sed -i '/open_1/a mount -o bind /userdisk/'$lamp'/data/www/document_root /userdisk/'$WebSystem'/\
/userdisk/'$lamp'/lampmanager/mount_things.sh\
/userdisk/'$lamp'/lampmanager/start_dropbear.sh'  /etc/rc.local


if grep -q $duanko /etc/config/firewall;then
echo "$duanko is  installed"
if  [ ! -z "$1" ] ; then
if  [ $1 == "move" ] ; then
if  [ ! -z "$2" ] ;  then
lamp=$2
fi
fi
fi
else
sed  -i '$a config rule '"'httpdwan'"' \
option src  '"'wan'"'\
option dest_port '"'$duanko'"'\
option proto  '"'tcp'"'\
option target  '"'ACCEPT'"'\
option name  '"''"'\\'"''"'httpd wan accept tcp port '$duanko''"'"'\\'"'''"''  /etc/config/firewall
fi


if [ ! -d "/userdisk/$WebSystem" ]; then
mkdir -p  /userdisk/$WebSystem
fi
mount -o bind /userdisk/$lamp/data/www/document_root /userdisk/$WebSystem/
/userdisk/$lamp/lampmanager/mount_things.sh
/userdisk/$lamp/lampmanager/start_dropbear.sh
/etc/init.d/firewall restart
echo "OK,fix Suecess ! "
exit
   fi
      fi
fi
# setup
if [ -z "$1" ]  ; then
setup_ok=1
fi

if  [ $setup_ok == "1" ] ; then
#if [ -z  "$1" ] ; then
if  grep -q '#open_1' /etc/rc.local; then
echo "Do not repeat the installation!"
exit
else
echo "Please wait..."
mount -o remount rw /
fi



if [ ! -d "/userdisk/$lamp" ] ; then
mkdir -p /userdisk/$lamp
fi

if [  -d "/userdisk/$lamp/etc" ] ; then
rm -r /userdisk/$lamp/etc
fi
mkdir -p /userdisk/$lamp/etc  

if [ -d "/userdisk/$lamp/usr" ] ; then
rm -r   /userdisk/$lamp/usr
fi
mkdir -p /userdisk/$lamp/usr  

if [ ! -d "/userdisk/$lamp/data" ] ;  then
mkdir -p /userdisk/$lamp/data
fi  

if [ ! -d "/userdisk/$lamp/data/www" ] ; then
mkdir -p /userdisk/$lamp/data/www
fi

if [ ! -d "/userdisk/$lamp/data/www/document_root" ] ; then
mkdir -p /userdisk/$lamp/data/www/document_root 
fi
echo "<?  phpinfo(); ?>">/userdisk/$lamp/data/www/document_root/phpinfo.php

if  [ -f "/userdisk/$WebSystem" ] ; then
rm -f /userdisk/$WebSystem
fi

if   [ -d  "/userdisk/$WebSystem" ] ;  then
echo "ok";
else
mkdir -p  /userdisk/$WebSystem
fi
if  [ ! -d "/userdisk/$lamp/data/mysql" ] ;  then
mkdir -p /userdisk/$lamp/data/mysql
fi

if [ ! -d "/userdisk/$lamp/data/mysql/data" ] ; then
mkdir -p /userdisk/$lamp/data/mysql/data
fi

if   [ -d  "/userdisk/$lamp/data/mysql/data/mysql" ]  ;  then
rm -r  /userdisk/$lamp/data/mysql/data/mysql
fi
mkdir  -p /userdisk/$lamp/data/mysql/data/mysql

mount -o bind /userdisk/$lamp/data/www/document_root /userdisk/$WebSystem/

#  being setup sign
echo "1">/userdisk/$lamp/setup_ing123

#  delete  old

if grep -q '#open_1' /etc/rc.local ; then
#sed -i -n '$!N;/\n#open_1/!P;D' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/d'  /etc/rc.local
fi

tar xvzf /userdisk/data/lampmanager.tar.gz -C /userdisk/$lamp/
echo "Please wait..."

cd /userdisk/$lamp/lampmanager 
sed  -i 's#lampmanager#lamp/lampmanager#g'  create_sandbox.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' create_sandbox.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' mount_things.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' stop_dropbear.sh 
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' umount_things.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' are_things_mounted.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' is_sandbox_created.sh
sed  -i 's#userdisk/lamp#userdisk/'$lamp'#g' start_dropbear.sh

cd /userdisk/$lamp/lampmanager && ./create_sandbox.sh

tar xvzf /userdisk/data/lamp.tgz -C /userdisk/$lamp
sed  -i '/config_foreach/a if [ -f setup_ing123 ]; then\
rm -f setup_ing123\
/usr/sbin/lighttpd -f  /etc/lighttpd/lighttpd.conf\
killall -TERM  mysqld\
mysql_install_db\
mysqld_safe &\
sleep 30\
mysqladmin -u root password '$admin'\
else\
/usr/sbin/lighttpd -f  /etc/lighttpd/lighttpd.conf\
killall -TERM  mysqld\
mysqld_safe &\
fi'  /userdisk/$lamp/etc/init.d/dropbear
#sed -i 's/3306/3307/g' /userdisk/$lamp/etc/my.cnf
cd /userdisk/$lamp/lampmanager && ./mount_things.sh && ./start_dropbear.sh

sed -i  '4c \        option RootLogin        '"'"'on'"'"'' /userdisk/$lamp/etc/config/dropbear
sed -i '1c  root:$1$NmI6FjHr$JuobZdWmS5NhG3HLDnfkf.:0:0:99999:7:::'   /userdisk/$lamp/etc/shadow

# add lamp to  rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\nmount -o bind \/userdisk\/'$lamp'\/data\/www\/document_root \/userdisk\/'$WebSystem'\n/'  /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\n#open_1 lamp\n/'  /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\n\/userdisk\/'$lamp'\/lampmanager\/mount_things.sh\n/'  /etc/rc.local
#sed -i '$!N;$!P;$!D;s/\(\n\)/\n\/userdisk\/'$lamp'\/lampmanager\/start_dropbear.sh\n/'  /etc/rc.local

sed -i '$!N;$!P;$!D;s/\(\n\)/\n#open_1 lamp\n/' /etc/rc.local
sed -i '/open_1/a mount -o bind /userdisk/'$lamp'/data/www/document_root /userdisk/'$WebSystem'/\
/userdisk/'$lamp'/lampmanager/mount_things.sh\
/userdisk/'$lamp'/lampmanager/start_dropbear.sh'  /etc/rc.local

sed -i '/server.port/d' /userdisk/$lamp/etc/lighttpd/lighttpd.conf
sed -i '/default: 80/a server.port = '$duanko'' /userdisk/$lamp/etc/lighttpd/lighttpd.conf

if grep -q $duanko /etc/config/firewall;then 
echo "$duanko Is  installed"
else 
sed  -i '$a config rule '"'httpdwan'"' \
option src  '"'wan'"'\
option dest_port '"'$duanko'"'\
option proto  '"'tcp'"'\
option target  '"'ACCEPT'"'\
option name  '"''"'\\'"''"'httpd wan accept tcp port '$duanko''"'"'\\'"'''"''  /etc/config/firewall
fi
 
cp /userdisk/data/libmysqlclient.so.16  /userdisk/$lamp/usr/lib/libmysqlclient.so.16

cd /userdisk
#echo "<?  phpinfo(); ?>">/userdisk/$lamp/data/www/document_root/phpinfo.php
/etc/init.d/firewall restart
echo " Successfully installed! "

else
if [ ! -z  "$1" ] ; then
if [ !  $1 == "a" ] ; then
echo "usage:"
echo "/userdisk/data/lamp.sh      -----setup  and the installation folder is  /userdisk/lamp" 
echo "/userdisk/data/lamp.sh a    -----Uninstall"
echo "/userdisk/data/lamp.sh fix  -----Upgrading repair"
echo "/userdisk/data/lamp.sh move lamp WebSystem 8088 admin   ----setup and user can change these values: lamp,WebSystem,8088,amin"

  fi
fi

# Uninstall
if [   $1 == "a" ]; then
if  grep -q '#open_1' /etc/rc.local; then 

if grep -q '#open_1' /etc/rc.local ; then
#sed -i -n '$!N;/\n#open_1/!P;D' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/{n;d}' /etc/rc.local
sed -i '/#open_1/d'  /etc/rc.local

fi

if grep -q 'httpdwan' /etc/config/firewall ; then
sed -i '/httpdwan/{n;d}' /etc/config/firewall
sed -i '/httpdwan/{n;d}' /etc/config/firewall
sed -i '/httpdwan/{n;d}' /etc/config/firewall
sed -i '/httpdwan/{n;d}' /etc/config/firewall
sed -i '/httpdwan/{n;d}' /etc/config/firewall
sed -i '/httpdwan/d'  /etc/config/firewall
fi

echo "Uninstall success!  Ready to restart..."
reboot
exit
esle
echo " Disalble uninstall!"
fi
fi
fi
